#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

// HUD: r=254 이동, r=253 머리(이동+확대), r=1 그림자
#define HUD_HEAD_SCALE 3.0
#define HUD_HEAD_DY 11.0

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    mat4 mvp = ProjMat * ModelViewMat;
    gl_Position = mvp * vec4(Position, 1.0);
    vec4 col = Color;
    int r = int(round(Color.r * 255.0));
    if (ProjMat[2][3] == 0.0 && gl_Position.y > 0.3 && (r == 254 || r == 253 || r == 1)) {
        if (r == 253) {
            float dx = (int(round(UV0.x * 8.0)) % 2 == 0) ? 8.0 : 0.0;
            float dy = (int(round(UV0.y * 8.0)) >= 2) ? 8.0 : 0.0;
            gl_Position.x += dx * (HUD_HEAD_SCALE - 1.0) * mvp[0][0];
            gl_Position.y += (dy * (HUD_HEAD_SCALE - 1.0) + HUD_HEAD_DY) * mvp[1][1];
        }
        gl_Position.x -= 1.0;
        col.r = (r == 1) ? 0.0 : 1.0;
    }

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;
}
