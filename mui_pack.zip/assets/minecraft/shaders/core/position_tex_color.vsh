#version 330

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 texCoord0;
out vec4 vertexColor;

// HUD: r=254 이동, r=253 머리(이동+확대), r=1 그림자
#define HUD_HEAD_SCALE 3.0
#define HUD_HEAD_DY 11.0

void main() {
    mat4 mvp = ProjMat * ModelViewMat;
    gl_Position = mvp * vec4(Position, 1.0);
    vec4 col = Color;
    if (ProjMat[2][3] == 0.0 && gl_Position.y > 0.3 && int(round(Color.r * 255.0)) == 253) {
        float dx = (int(round(UV0.x * 8.0)) % 2 == 0) ? 8.0 : 0.0;
        float dy = (int(round(UV0.y * 8.0)) >= 2) ? 8.0 : 0.0;
        gl_Position.x += dx * (HUD_HEAD_SCALE - 1.0) * mvp[0][0] - 1.0;
        gl_Position.y += (dy * (HUD_HEAD_SCALE - 1.0) + HUD_HEAD_DY) * mvp[1][1];
        col.r = 1.0;
    }

    texCoord0 = UV0;
    vertexColor = col;
}
